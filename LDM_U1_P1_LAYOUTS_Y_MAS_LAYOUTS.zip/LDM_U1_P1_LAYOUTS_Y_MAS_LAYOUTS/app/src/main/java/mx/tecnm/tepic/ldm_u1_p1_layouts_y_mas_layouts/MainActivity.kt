package mx.tecnm.tepic.ldm_u1_p1_layouts_y_mas_layouts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        menuprincipal.setOnItemClickListener { adapterView, view, i, l ->
            when(i){
                0->{
                    var pantalla1 = Intent(this, MainActivity2::class.java)
                    startActivity(pantalla1)
                }
                1->{
                    var pantalla2 = Intent(this, MainActivity3::class.java)
                    startActivity(pantalla2)
                }
                2->{
                    var pantalla3 = Intent(this, MainActivity4::class.java)
                    startActivity(pantalla3)
                }
                3->{
                    var pantalla4 = Intent(this, MainActivity5::class.java)
                    startActivity(pantalla4)
                }
                4->{
                    var pantalla5 = Intent(this, MainActivity6::class.java)
                    startActivity(pantalla5)
                }
                5->{
                    var pantalla6 = Intent(this, MainActivity7::class.java)
                    startActivity(pantalla6)
                }
                6->{
                    var pantalla7 = Intent(this, MainActivity8::class.java)
                    startActivity(pantalla7)
                }
                7->{
                    var pantalla8 = Intent(this, MainActivity9::class.java)
                    startActivity(pantalla8)
                }
                8->{
                    finish()
                }
            }
        }
    }
}