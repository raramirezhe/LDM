package mx.tecnm.tepic.ladm_u2_practica1_presentaciondediademuertos

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.CountDownTimer
import android.view.View

class Lienzo (p:MainActivity) : View(p) {
    val principal = p
    val catrina  = BitmapFactory.decodeResource(principal.resources,R.drawable.catrina)
    var posX = 2200f
    var mensaje = "RIP"


    val movimientocatrina = object : CountDownTimer(2000,80){
        override fun onTick(p0: Long) {
            posX-=5
            if(posX < -500) posX = 2200f
            invalidate()
        }

        override fun onFinish() {
            start()
        }

    }

    //CONSTRUCTOR
    init {
        movimientocatrina.start()
    }


    override fun onDraw(c: Canvas) {
        super.onDraw(c)

        val p = Paint()

        c.drawColor(Color.rgb(32,32,68))
        //Luna
        p.color = Color.WHITE
        c.drawCircle(250f,200f,75f,p)

        p.color = Color.rgb(32,32,68)
        c.drawCircle(290f,190f,50f,p)
        //Nube1
        p.color = Color.rgb(76,76,98)
        c.drawRect(700f,220f,1000f, 300f,p)
        c.drawCircle(700f,250f,50f,p)
        c.drawCircle(750f,220f,50f,p)
        c.drawCircle(800f,200f,50f,p)
        c.drawCircle(850f,180f,50f,p)
        c.drawCircle(900f,200f,50f,p)
        c.drawCircle(950f,220f,50f,p)
        c.drawCircle(1000f,250f,50f,p)
        //Nube 2
        p.color = Color.rgb(76,76,98)
        c.drawRect(1500f,370f,1800f, 450f,p)
        c.drawCircle(1500f,400f,50f,p)
        c.drawCircle(1550f,370f,50f,p)
        c.drawCircle(1600f,350f,50f,p)
        c.drawCircle(1650f,330f,50f,p)
        c.drawCircle(1700f,350f,50f,p)
        c.drawCircle(1750f,370f,50f,p)
        //Nube 3
        p.color = Color.rgb(76,76,98)
        c.drawRect(1200f,120f,1500f, 200f,p)
        c.drawCircle(1200f,150f,50f,p)
        c.drawCircle(1250f,120f,50f,p)
        c.drawCircle(1300f,100f,50f,p)
        c.drawCircle(1350f,80f,50f,p)
        c.drawCircle(1400f,100f,50f,p)
        c.drawCircle(1450f,120f,50f,p)
        c.drawCircle(1500f,150f,50f,p)
        //Cesped
        //0-1800
        p.color = Color.rgb(41,68,41)
        c.drawRect(1800f,700f,0f, 1000f,p)
        //Arbol
        p.color = Color.rgb(53,34,34)
        c.drawRect(420f,500f,520f, 750f,p)
        p.color = Color.rgb(43,115,42)
        c.drawCircle(465f,500f,100f,p)
        //Arbol2
        p.color = Color.rgb(53,34,34)
        c.drawRect(1650f,600f,1700f, 700f,p)
        p.color = Color.rgb(43,115,42)
        c.drawCircle(1675f,580f,50f,p)

        //LAPDIAS
        p.color = Color.rgb(147, 154, 150)

        c.drawCircle(1555f,535f, 70f,p)
        c.drawRect(1480f,500f,1630f,700f,p)

        c.drawCircle(1275f,535f, 70f,p)
        c.drawRect(1200f,500f,1350f,700f,p)

        c.drawCircle(975f,535f, 70f,p)
        c.drawRect(900f,500f,1050f,700f,p)

        c.drawCircle(675f,535f, 70f,p)
        c.drawRect(600f,500f,750f,700f,p)

        c.drawCircle(275f,535f, 70f,p)
        c.drawRect(200f,500f,350f,700f,p)



        p.textSize = 80f
        p.style = Paint.Style.FILL
        p.color = Color.BLACK
        c.drawText(mensaje,1495f,600f,p)
        c.drawText(mensaje,1215f,600f,p)
        c.drawText(mensaje,915f,600f,p)
        c.drawText(mensaje,615f,600f,p)
        c.drawText(mensaje,215f,600f,p)



        c.drawBitmap(catrina,posX,150f,p)


    }
}